
// import { database, ref, get } from "./firebase.js";
// import { database, ref, get } from "./firebase.js";
import { database, ref, get, set } from "./firebase.js";
import { onValue } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";
document.addEventListener("DOMContentLoaded", () => {
    const postsContainer = document.getElementById("discoverPosts");
    // const container = document.querySelector(".creators-grid");
    const container = document.getElementById("creatorsContainer");
    const loggedInEmail = localStorage.getItem("loggedInEmail");
    const currentUserId = loggedInEmail ? loggedInEmail.replace(/\./g, "_") : null;

// async function loadCreators() {
//     try {
//         // 🔥 Fetch full database
//         // const snapshot = await get(ref(database));
//         const snapshot = await get(ref(database, "users"));

//         if (!snapshot.exists()) {
//             container.innerHTML = "<p>No users found 🚫</p>";
//             return;
//         }

//         const data = snapshot.val();

//         // 🔥 Get both sources
//         const users = data.users || {};
//         const portfolioUsers = data.portfolio || {};

//         // 🔥 Merge ALL users
//         const allUsers = { ...users, ...portfolioUsers };

//         console.log("ALL USERS:", allUsers); // DEBUG

//         if (!container) {
//             console.error("Container not found ❌");
//             return;
//         }

//         container.innerHTML = "";

//         const fragment = document.createDocumentFragment();

//         // 🔥 LOOP OVER MERGED DATA (IMPORTANT FIX)
//         // Object.entries(allUsers).forEach(([userId, user]) => {

//         //     if (!user) return; // safety check

//         //     const name = user.name ? user.name : "No Name";

//         //     const bio = (user.portfolio && user.portfolio.bio)
//         //         ? user.portfolio.bio
//         //         : "No bio available";
                
//         //     const card = document.createElement("div");
//         //     card.classList.add("creator-card", "glass");

//         //     card.innerHTML = `
//         //         <h3>${name}</h3>
//         //         <p>${bio}</p>
//         //         <button class="view-profile-btn" data-id="${userId}">
//         //             View Profile
//         //         </button>
//         //     `;

//         //     fragment.appendChild(card);
//         // });
//         Object.entries(allUsers).forEach(([userId, user]) => {

//     // 🚫 Do not show current user
//     if (userId === currentUserId) return;

//     if (!user) return;

//     const name = user.name ? user.name : "No Name";

//     const bio = (user.portfolio && user.portfolio.bio)
//         ? user.portfolio.bio
//         : "No bio available";
        
//     const card = document.createElement("div");
//     card.classList.add("creator-card", "glass");

//     card.innerHTML = `
//         <h3>${name}</h3>
//         <p>${bio}</p>
//         <button class="view-profile-btn" data-id="${userId}">
//             View Profile
//         </button>
//     `;

//     fragment.appendChild(card);
//     });
//         container.appendChild(fragment);

//     } catch (error) {
//         console.error("Error:", error);
//         container.innerHTML = "<p>Error loading creators ❌</p>";
//     }
// }
async function loadCreators() {
    try {
        const snapshot = await get(ref(database, "users"));

        if (!snapshot.exists()) {
            container.innerHTML = "<p>No users found 🚫</p>";
            return;
        }

        const allUsers = snapshot.val(); // ✅ FIXED

        container.innerHTML = "";
        const fragment = document.createDocumentFragment();

        Object.entries(allUsers).forEach(([userId, user]) => {

            if (userId === currentUserId) return;
            if (!user) return;

   const name = user.name || "No Name";
const bio = user.portfolio?.bio || "No bio available";

const profile = user.portfolio || {};

const role = profile.niche || "Creator";
const skills = profile.skills || [];

const followers = user.followers
    ? Object.keys(user.followers).length
    : 0;

const avatar =
    profile.profileImage ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}`;

const card = document.createElement("div");
card.classList.add("creator-card", "glass");

card.innerHTML = `
<div class="creator-top">

    <img src="${avatar}" class="creator-avatar">

    <div class="creator-main">

        <h3>${name}</h3>

        <div class="creator-role">
            ${role}
        </div>

        <p class="creator-bio">
            ${bio}
        </p>

        <div class="creator-skills">
            ${skills.map(skill => `<span>${skill}</span>`).join("")}
        </div>

    </div>

</div>

<div class="creator-stats">
    <span>
        <i class="fas fa-users"></i>
        ${followers} Followers
    </span>
</div>

<div class="card-actions">

    <button class="view-profile-btn" data-id="${userId}">
        View Profile
    </button>

    <button class="connect-btn" data-id="${userId}">
        Connect
    </button>

</div>
`;

            fragment.appendChild(card);
        });

        container.appendChild(fragment);

    } catch (error) {
        console.error("Error:", error);
        container.innerHTML = "<p>Error loading creators ❌</p>";
    }
}
function loadDiscoverPosts() {
    const usersRef = ref(database, "users");

    onValue(usersRef, snapshot => {
        const data = snapshot.val();

        if (!postsContainer) return;

        postsContainer.innerHTML = "";

        if (!data) return;

        Object.entries(data).forEach(([userId, user]) => {

            const posts = user?.portfolio?.posts;

            if (!posts) return;

            Object.values(posts)
                .sort((a, b) => b.createdAt - a.createdAt)
                .forEach(post => {

                    const div = document.createElement("div");
                    div.classList.add("glass");
                    div.style.margin = "20px 0";
                    div.style.padding = "10px";

                    if (post.type === "image") {
                        div.innerHTML += `<img src="${post.fileUrl}" style="width:100%">`;
                    } else {
                        div.innerHTML += `<video controls src="${post.fileUrl}" style="width:100%"></video>`;
                    }

                    div.innerHTML += `<p>${post.caption}</p>`;

                    postsContainer.appendChild(div);
                });
        });
    });
}

    // 🔥 Navigation (VERY IMPORTANT)
//     container.addEventListener("click", (e) => {

//     const button = e.target.closest(".view-profile-btn");

//     if (button) {
//         const userId = button.dataset.id;

//         console.log("Clicked user:", userId); // 🔍 DEBUG

//         if (!userId) {
//             console.error("User ID missing ❌");
//             return;
//         }

//         window.location.href = `profile.html?id=${encodeURIComponent(userId)}`;
//     }
// });
container.addEventListener("click", async (e) => {

    const viewBtn = e.target.closest(".view-profile-btn");
    const connectBtn = e.target.closest(".connect-btn");

    // 👉 VIEW PROFILE
    if (viewBtn) {
        const userId = viewBtn.dataset.id;

        if (!userId) return;

        window.location.href = `profile.html?id=${encodeURIComponent(userId)}`;
    }

    // 👉 CONNECT
    if (connectBtn) {
        const targetUserId = connectBtn.dataset.id;

        if (!currentUserId) {
            alert("Login required ❌");
            return;
        }

        try {
            // prevent duplicate
            const existing = await get(ref(database, `connectionRequests/${targetUserId}/${currentUserId}`));
            if (existing.exists()) {
                alert("Already requested ⚠️");
                return;
            }

            // 🔥 save request
            await set(ref(database, `connectionRequests/${targetUserId}/${currentUserId}`), {
                from: currentUserId,
                status: "pending",
                createdAt: Date.now()
            });

            // 🔥 save notification
            // await set(ref(database, `notifications/${targetUserId}/${Date.now()}`), {
            //     type: "connection",
            //     from: currentUserId,
            //     message: "sent you a connection request",
            //     createdAt: Date.now()
            // });
            const notifId = Date.now();

await set(ref(database, `notifications/${targetUserId}/${notifId}`), {
    type: "connection",
    from: currentUserId,
    message: "sent you a connection request",
    status: "pending",   // ✅ ADD THIS
    createdAt: notifId
});

            // UI update
            connectBtn.innerText = "Requested";
            connectBtn.disabled = true;

        } catch (err) {
            console.error("Error:", err);
        }
    }
});

    // loadCreators();
    loadCreators();
    loadDiscoverPosts();
});
